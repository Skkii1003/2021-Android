package com.android.example.helloandroid

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

/**
 * 学习测试 LinearLayout
 */
class LinearLayoutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_linear_layout)
    }
}